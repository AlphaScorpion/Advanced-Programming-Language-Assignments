/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cecs524testjavaparser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;

public class CECS524TestJavaParser {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     * @throws org.antlr.runtime.RecognitionException
     */
    public static void main(String[] args) throws IOException, RecognitionException {
        
        String filePath =System.getProperty("user.dir") + File.separator + "src" + File.separator + args[0];
        ANTLRFileStream input = new ANTLRFileStream(filePath);
        JavaLexer lexer = new JavaLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        JavaParser parser = new JavaParser(tokens);

        parser.compilationUnit();
    }

}
