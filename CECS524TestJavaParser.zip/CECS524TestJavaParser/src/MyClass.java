
/*public class Base{
}

public class Class1{
*/




public class MyClass extends Base implements Class1 {
    private int x,y;
    public MyClass(){}
    public void hello(int ix, int iy){
    x=ix;
    y=iy;
    }
   /* public static void main(String[] args) {
        System.out.println("Hello");
    }*/
}
