/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package myclass;

/**
 *
 * @author aishu
 */
public class MyClass extends Base implements Class1 {
    private int x,y;
    public MyClass(){}
    public void hello(int ix, int iy){
    x=ix;
    y=iy;
    }
   
    public static void main(String[] args) {
       
    }
    
}
