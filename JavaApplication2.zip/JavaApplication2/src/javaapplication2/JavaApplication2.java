
package javaapplication2;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.TokenStream;

public class JavaApplication2 {
    
    public static void main(String[] args) throws IOException, RecognitionException, InterruptedException {
    /*System.out.println("Class name is " +args[0]);
    String cwd = Path.of(args[0]).toAbsolutePath().toString();
    System.out.println("Class name is " +cwd);
    File f = new File(cwd);
    System.out.println(f.getCanonicalPath());
    JavaLexer lexer = new JavaLexer(new ANTLRFileStream(args[0]));
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    JavaParser parser = new JavaParser((TokenStream) lexer);
    parser.compilationUnit();*/
    Thread.sleep(1000l); 		
    ANTLRFileStream input = new ANTLRFileStream(args[0]); 		
    JavaLexer lexer = new JavaLexer(input); 		
    CommonTokenStream tokens = new CommonTokenStream(lexer); 		
    JavaParser parser = new JavaParser(tokens); 		
    

    }
    private String[] args;
    
}

